1. Install Win64OpenSSL_Light-1_0_2d.exe
2. Run CreateCSR.bat to create SpiderCertificate.csr and SpiderCertificate.key
3. Visit Go Daddy's control panel and re-key using SpiderCertificate.csr
4. Get new SPC file from Go Daddy's control panel and rename to SpiderCertificate.spc
5. Run CreatePVK.bat to create SpiderCertificate.pvk
6. Run CreatePFX.bat to crete SpiderCertificate.pfx
Done!
